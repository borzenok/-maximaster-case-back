from django.contrib.auth.models import User, Group
from rest_framework import serializers
from .models import *


class RegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(
        max_length=128,
        min_length=8,
        write_only=True
    )
    token = serializers.CharField(max_length=255, read_only=True)

    class Meta:
        model = User
        fields = ['email', 'username', 'password', 'token']

    def create(self, validated_data):
        return User.objects.create_user(**validated_data)


class UserSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'url', 'username', 'email', 'groups']


class GroupSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Group
        fields = ['url', 'name']


class ProfileSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Profile
        fields = ['id', 'profile_type', 'first_name', 'last_name', 'city', 'nickname', 'social_email', 'social_phone', 'social_telegram', 'description']


class ProfileTasksSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = ['id', 'status', 'title', 'description', 'director', 'department', 'profile']

    # profile = ProfileSerializer(many=True, read_only=True)


class DepartmentSerializer(serializers.ModelSerializer):
    participants = ProfileSerializer(many=True)
    class Meta:
        model = Department
        fields = ['id', 'title', 'participants']
