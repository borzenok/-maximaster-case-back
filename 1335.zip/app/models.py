from django.db import models
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.models import User, Group
import jwt
from datetime import datetime, timedelta
from django.conf import settings
from django.contrib.auth.models import (AbstractBaseUser, PermissionsMixin, BaseUserManager)
import uuid
from django.utils import timezone


# class UserManager(BaseUserManager):
#     def _create_user(self, email, password, **extra_fields):
#         if not nickname:
#             raise ValueError('The given nickname must be set')
#         try:
#             with transaction.atomic():
#                 user = self.model(nickname=nickname, **extra_fields)
#                 user.set_password(password)
#                 user.save(using=self._db)
#                 return user
#         except:
#             raise
 
#     def create_user(self, email, password=None, **extra_fields):
#         extra_fields.setdefault('is_staff', False)
#         extra_fields.setdefault('is_superuser', False)
#         return self._create_user(nickname, password, **extra_fields)
 
#     def create_superuser(self, email, password, **extra_fields):
#         extra_fields.setdefault('is_staff', True)
#         extra_fields.setdefault('is_superuser', True)
 
#         return self._create_user(nickname, password=password, **extra_fields)


# class User(AbstractBaseUser, PermissionsMixin):
#     nickname = models.CharField(max_length=40, unique=True)
#     first_name = models.CharField(max_length=30, blank=True)
#     last_name = models.CharField(max_length=30, blank=True)
#     is_active = models.BooleanField(default=True)
#     is_staff = models.BooleanField(default=False)
#     date_joined = models.DateTimeField(default=timezone.now)
 
#     objects = UserManager()
 
#     USERNAME_FIELD = 'email'
#     REQUIRED_FIELDS = ['first_name', 'last_name']
 
#     def save(self, *args, **kwargs):
#         super(User, self).save(*args, **kwargs)
#         return self



class Company(models.Model):
	name = models.TextField(max_length=100, default='', blank=True)
	description = models.TextField(default='No data available', blank=True)

	def __str__(self):
		return self.name


class Profile(models.Model):
	class PositionInCompany(models.TextChoices):
		EMPLOYEE = 'E', _('Сотрудник')
		DIRECTOR = 'D', _('Директор')

	user = models.OneToOneField(User, on_delete=models.CASCADE, blank=True, related_name='user')
	profile_type = models.CharField(max_length=1, choices=PositionInCompany.choices, default=PositionInCompany.EMPLOYEE)
	first_name = models.TextField(max_length=100, default='', blank=True)
	last_name = models.TextField(max_length=100, default='', blank=True)
	# paronimic_name = models.TextField(max_length=100, default='', blank=True)
	city = models.TextField(max_length=100, default='City of the World', blank=True)
	nickname = models.TextField(max_length=50, default='', blank=True)
	social_email = models.TextField(max_length=50, default='', blank=True)
	social_phone = models.TextField(max_length=20, default='', blank=True)
	social_telegram = models.TextField(max_length=30, default='', blank=True)
	description = models.TextField(default='No data available', blank=True)
	company = models.ForeignKey(Company, on_delete=models.CASCADE, blank=True, related_name='company')

	def __str__(self):
		return self.first_name + ' ' + self.last_name

	def save(self, *args, **kwargs):
		self.user.first_name = self.first_name
		super(Profile, self).save(*args, **kwargs)


class Department(models.Model):
	title = models.TextField(max_length=100, default='', blank=True)
	# description = models.TextField(default='No data available', blank=True)
	participants = models.ManyToManyField(Profile, blank=True, default='', related_name='profiles')

	def __str__(self):
		return self.title


class Task(models.Model):
	class TaskStatus(models.TextChoices):
		ACCEPTED = 'ACCEPTED', _('Принята')
		INWORK = 'INWORK', _('В работе')
		MADE = 'MADE',  _('Сделана')

	status = models.TextField(max_length=10, choices=TaskStatus.choices, default=TaskStatus.ACCEPTED,)
	title = models.TextField(max_length=50, default='', blank=True)
	description = models.TextField(default='No data available', blank=True)
	director = models.ForeignKey(Profile, on_delete=models.CASCADE, blank=True, default='', related_name='direction_profile')
	department = models.ForeignKey(Department, on_delete=models.CASCADE, blank=True, default='', related_name='task_department')
	profile = models.ForeignKey(Profile, on_delete=models.CASCADE, blank=True, default='', related_name='task_profile')
	# full_time = models.TextField(default='0:0:0')
	# clicked_at = models.DateTimeField(default='')

	def __str__(self):
		return self.status + ': ' + self.title



class ImageProfile(models.Model):
	profile = models.ForeignKey(Profile, on_delete=models.CASCADE, blank=True, related_name='image_profile')
	image = models.ImageField()


class ImageCompany(models.Model):
	company = models.ForeignKey(Company, on_delete=models.CASCADE, blank=True, related_name='merits_company')
	image = models.ImageField()


		
		

		