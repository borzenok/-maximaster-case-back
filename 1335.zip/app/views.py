from django.contrib.auth.models import User, Group
from rest_framework import viewsets, permissions
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from django.core.serializers import serialize
from urllib import request
from django.http import HttpResponse
from itertools import chain
from app.serializers import *
from .models import *
from rest_framework.response import Response
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token

class AuthToken(ObtainAuthToken):
    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data,
                                           context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, created = Token.objects.get_or_create(user=user)
        return Response({
            'token': token.key,
            'user_id': user.pk,
            'email': user.email
        })



class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all().order_by('-date_joined')
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]


class GroupViewSet(viewsets.ModelViewSet):
    queryset = Group.objects.all()
    serializer_class = GroupSerializer
    permission_classes = [permissions.IsAuthenticated]


class LoginSet(viewsets.ModelViewSet):
    queryset = Profile.objects.all()
    serializer_class = GroupSerializer
    permission_classes = [permissions.IsAuthenticated]


class ProfilesViewSet(viewsets.ModelViewSet):
    queryset = Profile.objects.all()
    serializer_class = ProfileSerializer


class TasksViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = ProfileSerializer


class DepartmentsViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer


class ProfileTasksViewSet(viewsets.ModelViewSet):
    def get_serialize_data(self, user_id, **kwargs):
        print(user_id)
    #Need get user_id
    queryset = Task.objects.all()
    serializer_class = ProfileTasksSerializer


class DepartmentViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer


# def ProfileTasksViewSet(request, user_id):
#     queryset = Task.objects.filter(profile__id=int(user_id)).all()
#     print(queryset)
#     if queryset is not None:
#         queryset._meta.fields = ['id', 'status']
#         data = serialize('json', queryset)
#         return HttpResponse(data)
#     else:
#         return HttpResponse('None')
        