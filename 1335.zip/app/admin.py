from django.contrib import admin
from app.models import *


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
	pass


@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
	pass


@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
	pass


@admin.register(Department)
class TaskAdmin(admin.ModelAdmin):
	pass