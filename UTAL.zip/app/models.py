from django.db import models
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.models import User, Group



class Company(models.Model):
	name = models.TextField(max_length=100, default='', blank=True)
	description = models.TextField(default='No data available', blank=True)

	def __str__(self):
		return self.name


class Profile(models.Model):
	class PositionInCompany(models.TextChoices):
		EMPLOYEE = 'E', _('Сотрудник')
		DIRECTOR = 'D', _('Директор')

	user = models.OneToOneField(User, on_delete=models.CASCADE, blank=True, related_name='user')
	profile_type = models.CharField(max_length=1, choices=PositionInCompany.choices, default=PositionInCompany.EMPLOYEE)
	first_name = models.TextField(max_length=100, default='', blank=True)
	last_name = models.TextField(max_length=100, default='', blank=True)
	# paronimic_name = models.TextField(max_length=100, default='', blank=True)
	city = models.TextField(max_length=100, default='City of the World', blank=True)
	nickname = models.TextField(max_length=50, default='', blank=True)
	social_email = models.TextField(max_length=50, default='', blank=True)
	social_phone = models.TextField(max_length=20, default='', blank=True)
	social_telegram = models.TextField(max_length=30, default='', blank=True)
	description = models.TextField(default='No data available', blank=True)
	company = models.ForeignKey(Company, on_delete=models.CASCADE, blank=True, related_name='company')

	def __str__(self):
		return self.first_name + ' ' + self.last_name

	def save(self, *args, **kwargs):
		self.user.first_name = self.first_name
		super(Profile, self).save(*args, **kwargs)


class Department(models.Model):
	title = models.TextField(max_length=100, default='', blank=True)
	# description = models.TextField(default='No data available', blank=True)
	participants = models.ManyToManyField(Profile, blank=True, default='', related_name='profiles')

	def __str__(self):
		return self.title


class Task(models.Model):
	class TaskStatus(models.TextChoices):
		ACCEPTED = 'ACCEPTED', _('Принята')
		INWORK = 'INWORK', _('В работе')
		MADE = 'MADE',  _('Сделана')

	status = models.TextField(max_length=10, choices=TaskStatus.choices, default=TaskStatus.ACCEPTED,)
	title = models.TextField(max_length=50, default='', blank=True)
	description = models.TextField(default='No data available', blank=True)
	director = models.ForeignKey(Profile, on_delete=models.CASCADE, blank=True, default='', related_name='direction_profile')
	department = models.ForeignKey(Department, on_delete=models.CASCADE, blank=True, default='', related_name='task_department')
	profile = models.ForeignKey(Profile, on_delete=models.CASCADE, blank=True, default='', related_name='task_profile')

	def __str__(self):
		return self.status + ': ' + self.title



class ImageProfile(models.Model):
	profile = models.ForeignKey(Profile, on_delete=models.CASCADE, blank=True, related_name='image_profile')
	image = models.ImageField()


class ImageCompany(models.Model):
	company = models.ForeignKey(Company, on_delete=models.CASCADE, blank=True, related_name='merits_company')
	image = models.ImageField()


		
		

		