from django.contrib.auth.models import User, Group
from rest_framework import serializers
from .models import *


class UserSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'url', 'username', 'email', 'groups']


class GroupSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Group
        fields = ['url', 'name']


class ProfileSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Profile
        fields = ['id', 'profile_type', 'first_name', 'last_name', 'city', 'nickname', 'social_email', 'social_phone', 'social_telegram', 'description']


class ProfileTasksSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = ['id', 'status', 'title', 'description', 'director', 'department', 'profile']

    profile = ProfileSerializer(many=True, read_only=True)


class DepartmentSerializer(serializers.ModelSerializer):
    
    participants = ProfileSerializer(many=True)
    class Meta:
        model = Department
        fields = ['id', 'title', 'participants']
