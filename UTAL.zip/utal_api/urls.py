from django.contrib import admin
from django.urls import path
from django.urls import include, path
from rest_framework import routers
from app.views import *


router = routers.DefaultRouter()
# router.register(r'api/login', views.LoginSet)
# router.register(r'api/users', views.UserViewSet)
# router.register(r'api/groups', views.GroupViewSet)
router.register(r'api/profiles', ProfilesViewSet)
router.register(r'api/tasks', TasksViewSet)
router.register(r'api/<int:user_id>/tasks', ProfileTasksViewSet)



urlpatterns = [
    path('', include(router.urls)),
    # path('api/<user_id>/tasks', ProfileTasksViewSet),
    path('api-auth/', include('rest_framework.urls', namespace='rest_framework')),
    path('admin/', admin.site.urls),
]
